# LaneTracking

A road lane tracker based on Probabilistic Hough Transform for lanes detection and Kalman filter for tracking.
Implemented with Python and OpenCV.

<img src="http://i.imgur.com/o2JgOhm.png" alt="alt text" width="638" height="361">
