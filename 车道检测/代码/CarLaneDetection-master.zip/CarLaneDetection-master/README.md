# CarLaneDetection
参考知乎专栏文章：[从零开始学习无人驾驶技术 --- 车道检测](https://zhuanlan.zhihu.com/p/25354571)

需要安装[OpenCV](http://opencv.org)，建议从源码安装
