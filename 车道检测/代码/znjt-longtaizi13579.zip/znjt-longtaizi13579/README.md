znjt
